﻿using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Payments.AliPay.Models
{
    public class PaymentInfoModel : BaseNopModel
    {
    }
}