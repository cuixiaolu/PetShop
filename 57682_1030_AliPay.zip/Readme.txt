1. 'Nop.Plugin.Payments.AliPay' directory contains source code.
2. 'Payments.AliPay' contains binaries. Just drop it into \Plugins directory on your server.